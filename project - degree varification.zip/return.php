<?php
echo '
    <script>
        if (confirm("Are you sure you want to return?")) {
            window.location.href = "index.html";
        } else {
            window.location.href = "add_data.php";
        }
    </script>
    ';

exit();

?>