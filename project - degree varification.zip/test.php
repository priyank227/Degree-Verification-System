<?php
// Path to the Tesseract executable
$tesseractPath = 'C:\Users\Dell\tesseract.exe';

// Path to the image file
$imagePath = '2.png';

// Execute Tesseract OCR command
$output = shell_exec($tesseractPath . ' ' . $imagePath . ' stdout');

// Extract the name from the output
$lines = explode("\n", $output);
$name = trim($lines[6]);

// Extract the enrollment number from line number 0
$enrollmentNumber = trim(substr($lines[0], strpos($lines[0], 'Eno.') + strlen('Eno.')));

// Extract the CGPA
$startPosition = strpos($output, 'CGPA ') + strlen('CGPA ');
$stopPosition = strpos($output, 'having', $startPosition);
$cgpa = trim(substr($output, $startPosition, $stopPosition - $startPosition));

// Find the line number of "having" after the CGPA line
$havingLine = null;
$cgpaFound = false;

foreach ($lines as $lineNumber => $line) {
    if (!$cgpaFound && strpos($line, 'CGPA') !== false) {
        $cgpaFound = true;
        continue;
    }

    if ($cgpaFound && strpos($line, 'having') !== false) {
        $havingLine = $lineNumber;
        break;
    }
}

$havingLine = $havingLine - 1;

// Extract the class from the line before "having"
$startPosition = strpos($lines[$havingLine], 'in') + strlen('in');
$stopPosition = strpos($lines[$havingLine], 'With', $startPosition);
$class = trim(substr($lines[$havingLine], $startPosition, $stopPosition - $startPosition));

// Extract the branch
$startPosition = strpos($output, 'degree of') + strlen('degree of');
$stopPosition = strpos($output, 'in ', $startPosition);
$branch = trim(substr($output, $startPosition, $stopPosition - $startPosition));

// Database connection
$host = 'localhost';
$username = 'root';
$password = 'Pri@2004';
$database = 'student';

// Create a new MySQLi object
$mysqli = new mysqli($host, $username, $password, $database);

// Check the connection
if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

$stmt = $mysqli->prepare("INSERT INTO student_data (name, enrollment_number, cgpa, class, branch) VALUES (?, ?, ?, ?, ?)");


$stmt->bind_param("sssss", $name, $enrollmentNumber, $cgpa, $class, $branch);
$stmt->execute();

// for Check 
if ($stmt->affected_rows > 0) {
    echo "Data inserted successfully!";
} else {
    echo "Error inserting data: " . $stmt->error;
}

$stmt->close();
$mysqli->close();
?>
