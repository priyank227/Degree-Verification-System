<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .home{
            background-color: #008CBA;
            margin-bottom:10px;
            height:30px;
            width:70px;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            font-size: 15px;
            margin-left:1350px;
            cursor: pointer;
        }
        
    </style>
</head>
<body>
<button class="home" onclick="location.href='index.html'">Home</button>

<?php
// Path to the Tesseract executable
$tesseractPath = 'C:\Users\Dell\tesseract.exe';

// Database connection
$host = 'localhost';
$username = 'root';
$password = 'Pri@2004';
$database = 'student';

// Create a new MySQLi object
$mysqli = new mysqli($host, $username, $password, $database);

// Check the connection
if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

function extractMonthAndYear($passing) {
    $dateParts = explode('-', $passing);
    $month = strtolower($dateParts[0]);
    $year = intval($dateParts[1]);
    return array($month, $year);
}

function deffrences($row1, $row2)
{
    $differences = array();

    // Compare the fields
    if ($row1['name'] !== $row2['name']) {
        $differences[] = 'name';
    }
    if ($row1['cgpa'] !== $row2['cgpa']) {
        $differences[] = 'cgpa';
    }
    if (levenshtein($row1['branch'], $row2['branch']) > 3 ) {
        $differences[] = 'branch';

    }
    if ($row1['class'] !== $row2['class']) {
        $differences[] = 'class';
    }
    if($row1['faculty'] !== $row2['faculty']){
        $differences[] = 'faculty';
    }

    // Extract month and year for date1

    $passing1 = strtolower($row1['passing']);
    $passing2 = strtolower($row2['passing']);

    $date1Parts = explode('-', $passing1);
    $date1Month = $date1Parts[0];
    $date1Year = $date1Parts[1];

    // Extract month and year for date2
    $date2Parts = explode('-', $passing2);
    $date2Month = $date2Parts[0];
    $date2Year = $date2Parts[1];

    // Normalize the year for date2
    if (strlen($date2Year) == 2) {
        $date2Year = ($date2Year <= 99) ? '20' . $date2Year : '21' . $date2Year;
    }

    // Compare month and year
    if ($date1Month != $date2Month || $date1Year != $date2Year) {
        $differences[] = 'passing';
    }

    if (!empty($differences)) {

        foreach ($differences as $field) {
            echo "<tr>";
            echo "<td>" . $field . "</td>";
            echo "<td>" . $row1[$field] . "</td>";
            echo "<td>" . $row2[$field] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No differences found.</td></tr>";
    }
}

function matches($row1,$row2){
    $matches = array();

    // Compare the fields
    if ($row1['name'] == $row2['name']) {
        $matches[] = 'name';
    }
    if ($row1['cgpa'] == $row2['cgpa']) {
        $matches[] = 'cgpa';
    }
    if (levenshtein($row1['branch'], $row2['branch']) < 3 ) {
        $matches[] = 'branch';

    }
    if ($row1['class'] == $row2['class']) {
        $matches[] = 'class';
    }
    if($row1['faculty'] == $row2['faculty']){
        $matches[] = 'faculty';
    }

    $passing1 = strtolower($row1['passing']);
    $passing2 = strtolower($row2['passing']);

   // Extract month and year for date1
    $date1Parts = explode('-', $passing1);
    $date1Month = $date1Parts[0];
    $date1Year = $date1Parts[1];

    // Extract month and year for date2
    $date2Parts = explode('-', $passing2);
    $date2Month = $date2Parts[0];
    $date2Year = $date2Parts[1];

    // Normalize the year for date2
    if (strlen($date2Year) == 2) {
        $date2Year = ($date2Year <= 99) ? '20' . $date2Year : '21' . $date2Year;
    }

    // Compare month and year
    if ($date1Month == $date2Month && $date1Year == $date2Year) {
        $matches[] = 'passing';
    }

    if (!empty($matches)) {

        foreach ($matches as $field) {
            echo "<tr>";
            echo "<td>" . $field . "</td>";
            echo "<td>" . $row1[$field] . "</td>";
            echo "<td>" . $row2[$field] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No matches found.</td></tr>";
    }
}

// Check if the form was submitted
if (isset($_POST['submit'])) {
    // Check if an image file was uploaded
    if (isset($_FILES['image'])) {
        $imageFile = $_FILES['image']['tmp_name'];

        // Execute Tesseract OCR command
        $output = shell_exec($tesseractPath . ' ' . $imageFile . ' stdout');

        // Extract the name from the output
        $lines = explode("\n", $output);
        $name = trim($lines[6]);

        // Extract the enrollment number from line number 0
        $enrollmentNumber = trim(substr($lines[0], strpos($lines[0], 'Eno.') + strlen('Eno.')));

        // Extract the CGPA
        $startPosition = strpos($output, 'CGPA ') + strlen('CGPA ');
        $stopPosition = strpos($output, 'having', $startPosition);
        $cgpa = trim(substr($output, $startPosition, $stopPosition - $startPosition));

        // Find the line number of "having" after the CGPA line
        $havingLine = null;
        $cgpaFound = false;

        foreach ($lines as $lineNumber => $line) {
            if (!$cgpaFound && strpos($line, 'CGPA') !== false) {
                $cgpaFound = true;
                continue;
            }

            if ($cgpaFound && strpos($line, 'having') !== false) {
                $havingLine = $lineNumber;
                break;
            }
        }

        $havingLine = $havingLine - 1;

        // Extract the  class  from the line before "having"
        $startPosition = strpos($lines[$havingLine], 'in') + strlen('in');
        $stopPosition = strpos($lines[$havingLine], 'With', $startPosition);
        $class = trim(substr($lines[$havingLine], $startPosition, $stopPosition - $startPosition));

        // Extract the branch
        $startPosition = strpos($output, 'degree of') + strlen('degree of');
        $stopPosition = strpos($output, 'in ', $startPosition);
        $branch = trim(substr($output, $startPosition, $stopPosition - $startPosition));

        //Extract the college type
        $faculty = '';
        foreach ($lines as $line) {
            // Remove leading/trailing whitespace
            $line = trim($line);

            // Find the line starting with "Faculty"
            if (strpos($line, 'Faculty') === 0) {
                // Extract the letters after "Faculty"
                $letters0 = substr($line, strlen('Faculty'));
                $faculty = "Faculty".$letters0;
            }
            
            // Find the line starting with "held in"  Extract the date
            if (strpos($line, 'held in') !== false) {
                // Extract the letters after "held in" until the first occurrence of "."
                $letters = substr($line, strpos($line, 'held in') + strlen('held in'));
                $endPos = strpos($letters, '.');
                if ($endPos !== false) {
                    $letters = substr($letters, 0, $endPos);
                }
                $passing = trim($letters);
                break;
            }
        }

        // Check if a record with the same enrollment number exists
        $existingStmt = mysqli_prepare($mysqli, "SELECT * FROM student_data WHERE enrollment_number = ?");
        mysqli_stmt_bind_param($existingStmt, "s", $enrollmentNumber);
        mysqli_stmt_execute($existingStmt);
        $existingResult = mysqli_stmt_get_result($existingStmt);

        if (mysqli_num_rows($existingResult) > 0) {
            // Delete the existing record
            $deleteStmt = mysqli_prepare($mysqli, "DELETE FROM student_data WHERE enrollment_number = ?");
            mysqli_stmt_bind_param($deleteStmt, "s", $enrollmentNumber);
            mysqli_stmt_execute($deleteStmt);
            mysqli_stmt_close($deleteStmt);
        }

                // Insert the new record
                $insertStmt = mysqli_prepare($mysqli, "INSERT INTO student_data (name, enrollment_number, cgpa, class, branch,faculty,passing) VALUES (?, ?, ?, ?, ?,?,?)");
                mysqli_stmt_bind_param($insertStmt, "sssssss", $name, $enrollmentNumber, $cgpa, $class, $branch,$faculty, $passing);
                mysqli_stmt_execute($insertStmt);
        
                if (mysqli_stmt_affected_rows($insertStmt) > 0) {
                    echo '<script>
                        alert("Data inserted successfully!");
                        window.location.href = "index.html";
                    </script>';
                } else {
                    echo '<script>
                        alert("Error inserting data: ' . mysqli_stmt_error($insertStmt) . '");
                    </script>';
                }
        
                $insertStmt->close();
    }
}


// Check if the "compare" button is clicked
if (isset($_POST['compare'])) {

    if (isset($_FILES['image'])) {
        $imageFile = $_FILES['image']['tmp_name'];

        // Execute Tesseract OCR command
        $output = shell_exec($tesseractPath . ' ' . $imageFile . ' stdout');

        // Extract the name from the output
        $lines = explode("\n", $output);
        $name = trim($lines[6]);

        // Extract the enrollment number from line number 0
        $enrollmentNumber = trim(substr($lines[0], strpos($lines[0], 'Eno.') + strlen('Eno.')));

        // Step 2: Retrieve data and perform comparison

        $sql = "SELECT * FROM student_data WHERE enrollment_number = '$enrollmentNumber'";
        $result1 = $mysqli->query($sql);

        $sql = "SELECT * FROM student_new WHERE enrollment_number = '$enrollmentNumber'";
        $result2 = $mysqli->query($sql);

        $row1 = $result1->fetch_assoc();
        $row2 = $result2->fetch_assoc();

        // Step 3: Generate HTML output
        echo "<style>
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    padding: 8px;
                    text-align: left;
                    border-bottom: 1px solid #ddd;
                }
                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }
                tr:hover {
                    background-color: #e2e2e2;
                }
                .highlight {
                    background-color: #FF0000;
                }
                th{
                    background-color: #4CAF50;

                }
              </style>";

        echo "<h3>Defferences:</h3>";
        echo "<table>";
        echo "<tr>
                <th>Field</th>
                <th>Data in Degree</th>
                <th>Data in excel file</th>
            </tr>";
    deffrences($row1, $row2);

            echo "</table>";
            echo "<h3>Matches:</h3>";
            echo "<table>";
            echo "<tr>
                    <th>Field</th>
                    <th>Data in Degree</th>
                    <th>Data in excel file</th>
                </tr>";
    matches($row1,$row2);

        echo "</table>";
        
    }
}
$mysqli->close();
?>
</body>
</html>