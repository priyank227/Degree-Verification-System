<!DOCTYPE html>
<html lang="en">
<head>
<script type = "text/javascript" >  
    function preventBack() { window.history.forward(); }  
    setTimeout("preventBack()", 0);  
    window.onunload = function () { null };  
  </script> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f1f1f1;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #555;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .return-button {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 10px 20px;
            cursor: pointer;
        }

    </style>
</head>
<body>
    <h1>Student Data</h1>

    <form method="post" action="import.php" enctype="multipart/form-data">
        <input type="file" name="excel_file" accept=".csv" required>
        <input type="submit" name="import" value="Import" required>
    </form>

    <form method="post" action="delete.php">
        <input type="submit" name="delete" value="Delete All Data">
    </form>

    <table>
        <tr>
            <th>Name</th>
            <th>Enrollment No.</th>
            <th>CGPA</th>
            <th>Class</th>
            <th>Branch</th>
            <th>Faculty</th>
            <th>Passing</th>
        </tr>

        <?php
        $db = mysqli_connect('localhost', 'root', 'Pri@2004', 'student');
        $query = "SELECT * FROM student_new";
        $row = mysqli_query($db, $query);

        while ($data = mysqli_fetch_array($row)) {
            ?>
            <tr>
                <td><?= $data['name'] ?></td>
                <td><?= $data['enrollment_number'] ?></td>
                <td><?= $data['cgpa'] ?></td>
                <td><?= $data['class'] ?></td>
                <td><?= $data['branch'] ?></td>
                <td><?= $data['faculty'] ?></td>
                <td><?= $data['passing'] ?></td>
            </tr>
            <?php
        }
        ?>
    </table>

    <!-- <button class="return-button" onclick="location.href='index.html';">Return</button> -->
    <form class="return-button" method="post" action="return.php">
        <input type="submit" name="return" value="Return">
    </form>

</body>
</html>
