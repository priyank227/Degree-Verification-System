<?php
if (isset($_POST['import'])) {
    if (move_uploaded_file($_FILES['excel_file']['tmp_name'], $_FILES['excel_file']['name'])) {
        $file = fopen($_FILES['excel_file']['name'], 'r');
        if ($file !== false) {
            $db = mysqli_connect('localhost', 'root', 'Pri@2004', 'student');

            $firstLine = true; // Add this line to skip the first line

            while (($row = fgetcsv($file)) !== false) {
                if ($firstLine) {
                    $firstLine = false;
                    continue; // Skip the first line
                }

                $name = str_replace(array("\r\n", "\r", "\n"), ' ', $row[0]);
                $enrollment_number = isset($row[1]) && is_numeric($row[1]) ? intval($row[1]) : 0;
                $cgpa = isset($row[2]) ? floatval(str_replace(',', '.', $row[2])) : null;
                $class = $row[3];

                $branch = '';
                if (isset($row[4])) {
                    $branch_lines = explode("\n", $row[4]);
                    $branch = trim(implode(' ', $branch_lines));
                }

                $faculty = '';
                if (isset($row[5])) {
                    $faculty_lines = explode("\n", $row[5]);
                    $faculty = trim(implode(' ', $faculty_lines));
                }

                $passing = '';
                if (isset($row[6])) {
                    $passing_lines = explode("\n", $row[6]);
                    $passing = trim(implode(' ', $passing_lines));
                }


                $query = "INSERT INTO student_new (Name, enrollment_number, cgpa, class, branch,faculty,passing) ";
                $query .= "VALUES ('$name', '$enrollment_number', " . ($cgpa !== null ? "'$cgpa'" : "NULL") . ", '$class', '$branch','$faculty','$passing')";
                mysqli_query($db, $query);
            }

            fclose($file);

            echo "<script>window.location.href='index.php';</script>";
        }
    }
}

header("Location: add_data.php");
exit();
?>
