<?php
$db = mysqli_connect('localhost', 'root', 'Pri@2004', 'student');

$query = "DELETE FROM student_new";
mysqli_query($db, $query);

header("Location: add_data.php");
exit();
?>
