import fitz
import os
import pandas as pd

# Open the PDF file
pdf_path = '91800101017.pdf'
with fitz.open(pdf_path) as pdf:

    page = pdf.load_page(0)
    text = page.get_text("text")

    lines = text.split('\n')
    line = lines[4]
    print(f"{line}\n")
    
filename = 'pdf_to_text.xlsx'

df = pd.DataFrame({'Name': [line]})
if os.path.isfile(filename):
    with pd.ExcelWriter(filename, mode='a', if_sheet_exists='replace') as writer:
        df.to_excel(writer, sheet_name='Sheet1', index=False)
else:
    df.to_excel(filename, index=False)
