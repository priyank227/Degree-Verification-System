<?php
echo '
    <script>
        if (confirm("Are you sure you want to delete all data?")) {
            window.location.href = "confirm_delete.php";
        } else {
            window.location.href = "add_data.php";
        }
    </script>
    ';

exit();

?>