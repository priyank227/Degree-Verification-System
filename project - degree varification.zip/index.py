import os
import pytesseract as tess
from PIL import Image
import pandas as pd

tess.pytesseract.tesseract_cmd = r'C:\Users\Dell\tesseract.exe'

# List of image filenames
image_filenames = ['1.png', '2.png', '3.png']  # Add more filenames if needed

# Initialize an empty DataFrame
df = pd.DataFrame(columns=['Name'])

for image_filename in image_filenames:
    img = Image.open(image_filename)
    text = tess.image_to_string(img)

    lines = text.split('\n')
    line = lines[6]
    print(line)

    df = pd.concat([df, pd.DataFrame({'Name': [line]})], ignore_index=True)

# Output file
filename = 'img_to_text.xlsx'

if os.path.isfile(filename):
    # Update existing file
    with pd.ExcelWriter(filename, mode='a', if_sheet_exists='replace') as writer:
        df.to_excel(writer, sheet_name='Sheet1', index=False)
else:
    # Create new file
    df.to_excel(filename, index=False)
